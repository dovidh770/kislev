<footer class="bg-stone-950 text-stone-300" aria-label="Site footer">
  <div class="mx-auto max-w-7xl px-6 py-14 lg:px-8">
    <div class="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
      <div class="lg:col-span-1">
        <a href="/" class="inline-flex items-baseline gap-2" aria-label="Pumbi home">
          <span class="font-serif text-3xl font-semibold tracking-tight text-amber-300">Pumbi</span>
          <span class="text-xs font-semibold uppercase tracking-[0.18em] text-stone-400">Judaica auctions</span>
        </a>
        <p class="mt-5 max-w-xs text-sm leading-6 text-stone-400">The marketplace and operating platform for exceptional Judaica auctions, trusted auction houses, and discerning collectors.</p>
      </div>
      <div>
        <h2 class="text-sm font-semibold uppercase tracking-[0.16em] text-amber-200">Explore</h2>
        <ul class="mt-5 space-y-3 text-sm">
          <li><a class="transition hover:text-amber-200" href="/#auctions">Upcoming auctions</a></li>
          <li><a class="transition hover:text-amber-200" href="/#collections">Judaica collections</a></li>
          <li><a class="transition hover:text-amber-200" href="/#open-auction">Pumbi Open Auction</a></li>
          <li><a class="transition hover:text-amber-200" href="/dashboard">My account</a></li>
        </ul>
      </div>
      <div>
        <h2 class="text-sm font-semibold uppercase tracking-[0.16em] text-amber-200">For professionals</h2>
        <ul class="mt-5 space-y-3 text-sm">
          <li><a class="transition hover:text-amber-200" href="/auction-houses/signup">Join as an auction house</a></li>
          <li><a class="transition hover:text-amber-200" href="/seller">Auction house portal</a></li>
          <li><a class="transition hover:text-amber-200" href="/#open-auction">Submit to the Open Auction</a></li>
          <li><a class="transition hover:text-amber-200" href="mailto:hello@pumbi.com?subject=Pumbi%20platform%20inquiry">Talk with Pumbi</a></li>
        </ul>
      </div>
      <div>
        <h2 class="text-sm font-semibold uppercase tracking-[0.16em] text-amber-200">A better way to auction Judaica</h2>
        <p class="mt-5 text-sm leading-6 text-stone-400">Built for detailed cataloging, serious collecting, and the relationships that make exceptional objects matter.</p>
        <a href="/auction-houses/signup" class="mt-5 inline-flex text-sm font-semibold text-amber-200 transition hover:text-amber-100">Build your auction house on Pumbi <span aria-hidden="true">→</span></a>
      </div>
    </div>
    <div class="mt-14 flex flex-col gap-3 border-t border-stone-800 pt-7 text-xs text-stone-500 sm:flex-row sm:items-center sm:justify-between">
      <p>© {new Date().getFullYear()} Pumbi. Judaica auctions, thoughtfully connected.</p>
      <p>For collectors, consignors, and auction houses.</p>
    </div>
  </div>
</footer>
