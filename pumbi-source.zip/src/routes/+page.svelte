<svelte:head>
  <title>Pumbi | Judaica Auctions for Collectors & Auction Houses</title>
  <meta name="description" content="Discover Judaica auctions, connect with specialist auction houses, and consign to Pumbi's curated Open Auction. Explore ceremonial silver, manuscripts, textiles, and Jewish art." />
  <meta name="keywords" content="Judaica auctions, Jewish art auction, ceremonial silver, Hebrew manuscripts, Torah ornaments, auction house platform" />
  <meta property="og:title" content="Pumbi | Judaica Auctions for Collectors & Auction Houses" />
  <meta property="og:description" content="A dedicated marketplace and operating platform for exceptional Judaica auctions." />
</svelte:head>

<script>
  const collections = [
    { number: '01', title: 'Ceremonial silver', copy: 'Kiddush cups, spice towers, Seder plates, Torah finials, and objects of ritual beauty.' },
    { number: '02', title: 'Books & manuscripts', copy: 'Hebrew printing, illuminated texts, rabbinic works, letters, and historical documents.' },
    { number: '03', title: 'Textiles & ritual art', copy: 'Torah mantles, parochets, tallitot, embroidered works, and synagogue art.' },
    { number: '04', title: 'Jewish art & heritage', copy: 'Israeli art, folk art, Holocaust-era material, and objects of lived Jewish history.' }
  ];

  const platformFeatures = [
    { title: 'A marketplace built for Judaica', copy: 'Bring collectors to a place where provenance, material, region, inscriptions, and ritual use are part of the conversation.' },
    { title: 'Your auction house, amplified', copy: 'Run sales under your own identity while using Pumbi for cataloging, bidder management, marketing, and operations.' },
    { title: 'From discovery to delivery', copy: 'A connected experience for browsing, bidder approval, live and timed auctions, payment, and post-sale fulfillment.' }
  ];
</script>

<main class="overflow-hidden bg-[#f7f4ed] text-stone-900">
  <section class="relative isolate border-b border-stone-200 bg-stone-950 text-white">
    <div class="absolute inset-0 opacity-35" aria-hidden="true">
      <div class="absolute -left-24 top-0 h-96 w-96 rounded-full bg-amber-500 blur-3xl"></div>
      <div class="absolute right-0 top-24 h-80 w-80 rounded-full bg-orange-900 blur-3xl"></div>
      <div class="absolute inset-0 bg-[linear-gradient(115deg,rgba(12,10,9,.95),rgba(12,10,9,.72))]"></div>
    </div>
    <div class="relative mx-auto grid max-w-7xl gap-14 px-6 py-20 lg:grid-cols-[1.1fr_.9fr] lg:px-8 lg:py-28">
      <div class="max-w-3xl">
        <p class="mb-6 text-xs font-bold uppercase tracking-[0.25em] text-amber-300">Judaica, gathered with care</p>
        <h1 class="font-serif text-5xl leading-[.98] tracking-tight sm:text-6xl lg:text-7xl">Where exceptional Judaica finds its next steward.</h1>
        <p class="mt-7 max-w-xl text-lg leading-8 text-stone-300">Pumbi brings specialist auction houses, collectors, and consignors together around the objects, stories, and scholarship of Jewish life.</p>
        <div class="mt-9 flex flex-wrap gap-4">
          <a href="#auctions" class="rounded-sm bg-amber-300 px-6 py-3 text-sm font-bold text-stone-950 transition hover:bg-amber-200">Explore auctions</a>
          <a href="/auction-houses/signup" class="rounded-sm border border-stone-500 px-6 py-3 text-sm font-bold text-white transition hover:border-amber-200 hover:text-amber-200">For auction houses</a>
        </div>
        <div class="mt-12 flex flex-wrap gap-x-8 gap-y-4 border-t border-stone-700 pt-7 text-sm text-stone-300">
          <span><strong class="font-semibold text-amber-200">Specialist</strong> cataloging</span>
          <span><strong class="font-semibold text-amber-200">Trusted</strong> bidding</span>
          <span><strong class="font-semibold text-amber-200">Global</strong> discovery</span>
        </div>
      </div>
      <div class="relative self-end" aria-label="Judaica auction platform preview">
        <div class="relative mx-auto max-w-md border border-amber-200/30 bg-stone-900 p-5 shadow-2xl shadow-black/30 sm:p-7">
          <div class="flex items-center justify-between border-b border-stone-700 pb-4 text-xs uppercase tracking-[0.16em] text-stone-400"><span>Featured object</span><span class="text-amber-200">View catalog</span></div>
          <div class="mt-6 aspect-[4/3] bg-[radial-gradient(circle_at_50%_35%,#d9a95e_0_5%,#7c4c1e_6%,#23150e_34%,#100d0b_70%)] p-7">
            <div class="flex h-full items-center justify-center border border-amber-100/30"><span class="font-serif text-8xl text-amber-100/90">מ</span></div>
          </div>
          <p class="mt-6 text-xs font-bold uppercase tracking-[0.16em] text-amber-200">Ceremonial silver</p>
          <h2 class="mt-2 font-serif text-3xl leading-tight">Objects with a life beyond the auction room.</h2>
          <div class="mt-5 flex items-center justify-between text-sm text-stone-400"><span>Catalog, research, bid</span><span>01 / 04</span></div>
        </div>
        <div class="absolute -bottom-8 -left-8 hidden border border-amber-200/30 bg-amber-300 px-5 py-4 text-sm font-bold text-stone-950 shadow-xl sm:block">A focused marketplace for a global collecting community.</div>
      </div>
    </div>
  </section>

  <section id="auctions" class="mx-auto max-w-7xl px-6 py-20 lg:px-8">
    <div class="grid gap-10 lg:grid-cols-[.75fr_1.25fr] lg:items-end">
      <div><p class="text-xs font-bold uppercase tracking-[0.22em] text-amber-800">Discover what matters</p><h2 class="mt-4 font-serif text-4xl leading-tight sm:text-5xl">Find the sales worth following.</h2></div>
      <p class="max-w-2xl text-lg leading-8 text-stone-600">Explore curated Judaica auctions from independent specialists. Follow a house, research a lot, register to bid, and keep every important sale in view.</p>
    </div>
    <div id="collections" class="mt-12 grid gap-px overflow-hidden border border-stone-300 bg-stone-300 md:grid-cols-2">
      {#each collections as collection}
        <a href="/" class="group bg-[#f7f4ed] p-7 transition hover:bg-stone-950 hover:text-white sm:p-9">
          <p class="text-xs font-bold tracking-[0.18em] text-amber-800 group-hover:text-amber-300">{collection.number}</p>
          <h3 class="mt-9 font-serif text-3xl">{collection.title}</h3>
          <p class="mt-4 max-w-sm text-sm leading-6 text-stone-600 group-hover:text-stone-300">{collection.copy}</p>
          <span class="mt-8 inline-flex text-sm font-bold text-stone-900 group-hover:text-amber-200">Explore the category <span class="ml-2" aria-hidden="true">→</span></span>
        </a>
      {/each}
    </div>
  </section>

  <section class="border-y border-stone-200 bg-white">
    <div class="mx-auto max-w-7xl px-6 py-20 lg:px-8">
      <p class="text-xs font-bold uppercase tracking-[0.22em] text-amber-800">Built for the people who make the sale happen</p>
      <div class="mt-5 flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
        <h2 class="max-w-3xl font-serif text-4xl leading-tight sm:text-5xl">The tools of a serious auction platform, shaped around a specialist category.</h2>
        <a href="/auction-houses/signup" class="shrink-0 text-sm font-bold text-amber-800 underline decoration-amber-400 underline-offset-8 hover:text-stone-950">Bring your auction house to Pumbi</a>
      </div>
      <div class="mt-14 grid gap-10 border-t border-stone-200 pt-10 md:grid-cols-3">
        {#each platformFeatures as feature, index}
          <article><p class="font-serif text-4xl text-amber-700">0{index + 1}</p><h3 class="mt-5 text-xl font-bold">{feature.title}</h3><p class="mt-3 text-sm leading-6 text-stone-600">{feature.copy}</p></article>
        {/each}
      </div>
    </div>
  </section>

  <section id="open-auction" class="bg-[#b8752d] text-stone-950">
    <div class="mx-auto grid max-w-7xl gap-12 px-6 py-20 lg:grid-cols-[1fr_.9fr] lg:px-8 lg:py-24">
      <div><p class="text-xs font-bold uppercase tracking-[0.22em] text-stone-800">Introducing the Pumbi Open Auction</p><h2 class="mt-5 max-w-3xl font-serif text-5xl leading-[1.02] sm:text-6xl">One monthly sale. A wider path to market.</h2></div>
      <div class="max-w-xl lg:pt-4">
        <p class="text-lg leading-8 text-stone-900">The Pumbi Open Auction is a curated platform sale for Judaica. Eligible sellers submit lots; Pumbi reviews, catalogs, markets, and conducts the auction for a global audience of collectors.</p>
        <div class="mt-8 flex flex-wrap gap-4"><a href="mailto:hello@pumbi.com?subject=Open%20Auction%20submission" class="rounded-sm bg-stone-950 px-6 py-3 text-sm font-bold text-white transition hover:bg-stone-800">Submit a lot</a><a href="/auction-houses/signup" class="rounded-sm border border-stone-900 px-6 py-3 text-sm font-bold transition hover:bg-amber-200">Partner with Pumbi</a></div>
        <p class="mt-6 text-sm text-stone-800">Monthly themed auctions • Expert review • Clear consignment process</p>
      </div>
    </div>
  </section>

  <section class="mx-auto max-w-7xl px-6 py-20 text-center lg:px-8">
    <p class="text-xs font-bold uppercase tracking-[0.22em] text-amber-800">Start here</p>
    <h2 class="mx-auto mt-4 max-w-3xl font-serif text-4xl leading-tight sm:text-5xl">A more considered home for Judaica auctions.</h2>
    <p class="mx-auto mt-5 max-w-2xl text-lg leading-8 text-stone-600">Whether you are building a sale, looking for a rare object, or considering a consignment, Pumbi is designed to make the next step clear.</p>
    <div class="mt-9 flex flex-wrap justify-center gap-4"><a href="/auth/register" class="rounded-sm bg-stone-950 px-6 py-3 text-sm font-bold text-white transition hover:bg-stone-800">Create a collector account</a><a href="/auction-houses/signup" class="rounded-sm border border-stone-400 px-6 py-3 text-sm font-bold text-stone-900 transition hover:border-stone-950">Register an auction house</a></div>
  </section>
</main>
