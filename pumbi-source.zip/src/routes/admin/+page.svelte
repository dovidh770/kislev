<svelte:head>
  <title>Admin | Pumbi</title>
  <meta name="robots" content="noindex, nofollow" />
</svelte:head>

<script>
  let { data } = $props();
  let activeTab = $state('users');
  let query = $state('');

  const tabs = [
    { id: 'users', label: 'Users', items: data.users },
    { id: 'houses', label: 'Auction houses', items: data.auctionHouses },
    { id: 'auctions', label: 'Auctions', items: data.auctions },
    { id: 'lots', label: 'Lots', items: data.lots }
  ];

  function matches(item) {
    if (!query.trim()) return true;
    return JSON.stringify(item).toLowerCase().includes(query.trim().toLowerCase());
  }

  function formatDate(value) {
    if (!value) return '—';
    return new Intl.DateTimeFormat('en-US', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
  }

  function statusClass(status) {
    const colors = {
      LIVE: 'bg-rose-100 text-rose-800',
      UPCOMING: 'bg-sky-100 text-sky-800',
      ENDED: 'bg-stone-200 text-stone-700',
      ACTIVE: 'bg-emerald-100 text-emerald-800',
      SOLD: 'bg-violet-100 text-violet-800',
      UNSOLD: 'bg-amber-100 text-amber-900',
      WITHDRAWN: 'bg-stone-200 text-stone-700'
    };
    return colors[status] || 'bg-stone-100 text-stone-700';
  }
</script>

<main class="min-h-screen bg-stone-100 px-4 py-8 sm:px-6 lg:px-8">
  <div class="mx-auto max-w-7xl">
    <div class="rounded-sm border border-amber-300 bg-amber-50 px-5 py-4 text-sm text-amber-950">
      <strong>Temporary open admin:</strong> this page has no password protection by request. Add role-based access before production.
    </div>
    {#if data.loadError}
      <div class="mt-4 rounded-sm border border-rose-200 bg-rose-50 px-5 py-4 text-sm text-rose-900">{data.loadError}</div>
    {/if}

    <header class="mt-8 flex flex-col gap-5 border-b border-stone-300 pb-7 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <p class="text-xs font-bold uppercase tracking-[0.2em] text-amber-800">Pumbi operations</p>
        <h1 class="mt-2 font-serif text-4xl text-stone-950">Admin overview</h1>
        <p class="mt-2 text-stone-600">Review people, auction houses, sales, and catalog inventory.</p>
      </div>
      <label class="relative block w-full lg:w-80">
        <span class="sr-only">Search current table</span>
        <input bind:value={query} type="search" placeholder="Search the current table" class="w-full rounded-sm border border-stone-300 bg-white px-4 py-3 text-sm outline-none transition placeholder:text-stone-400 focus:border-amber-700 focus:ring-1 focus:ring-amber-700" />
      </label>
    </header>

    <section class="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-label="Record counts">
      {#each tabs as tab}
        <button onclick={() => { activeTab = tab.id; query = ''; }} class="border p-5 text-left transition {activeTab === tab.id ? 'border-stone-950 bg-stone-950 text-white' : 'border-stone-200 bg-white hover:border-amber-700'}">
          <p class="text-sm font-medium {activeTab === tab.id ? 'text-stone-300' : 'text-stone-500'}">{tab.label}</p>
          <p class="mt-2 font-serif text-4xl">{tab.items.length}</p>
        </button>
      {/each}
    </section>

    <section class="mt-8 overflow-hidden border border-stone-200 bg-white shadow-sm">
      <div class="flex flex-wrap gap-2 border-b border-stone-200 bg-stone-50 px-4 py-3">
        {#each tabs as tab}
          <button onclick={() => { activeTab = tab.id; query = ''; }} class="rounded-sm px-3 py-2 text-sm font-semibold transition {activeTab === tab.id ? 'bg-stone-950 text-white' : 'text-stone-600 hover:bg-stone-200'}">{tab.label}</button>
        {/each}
      </div>

      {#if activeTab === 'users'}
        <div class="overflow-x-auto"><table class="w-full min-w-[760px] text-left text-sm"><thead class="border-b border-stone-200 bg-white text-xs uppercase tracking-wide text-stone-500"><tr><th class="px-5 py-4">User</th><th class="px-5 py-4">Role</th><th class="px-5 py-4">Auction house</th><th class="px-5 py-4">Verification</th><th class="px-5 py-4">Joined</th></tr></thead><tbody class="divide-y divide-stone-100">
          {#each data.users.filter(matches) as user}<tr><td class="px-5 py-4"><p class="font-semibold text-stone-900">{user.name || 'Unnamed user'}</p><p class="mt-1 text-stone-500">{user.email}</p></td><td class="px-5 py-4">{user.role}</td><td class="px-5 py-4">{user.auctionHouse?.name || '—'}</td><td class="px-5 py-4"><span class="text-xs {user.isVerifiedBidder ? 'text-emerald-700' : 'text-stone-500'}">{user.isVerifiedBidder ? 'Bidder verified' : 'Not verified'}</span></td><td class="px-5 py-4 text-stone-500">{formatDate(user.createdAt)}</td></tr>{:else}<tr><td colspan="5" class="px-5 py-12 text-center text-stone-500">No users match your search.</td></tr>{/each}
        </tbody></table></div>
      {:else if activeTab === 'houses'}
        <div class="overflow-x-auto"><table class="w-full min-w-[760px] text-left text-sm"><thead class="border-b border-stone-200 bg-white text-xs uppercase tracking-wide text-stone-500"><tr><th class="px-5 py-4">Auction house</th><th class="px-5 py-4">Slug / domain</th><th class="px-5 py-4">Team</th><th class="px-5 py-4">Auctions</th><th class="px-5 py-4">Status</th></tr></thead><tbody class="divide-y divide-stone-100">
          {#each data.auctionHouses.filter(matches) as house}<tr><td class="px-5 py-4"><p class="font-semibold text-stone-900">{house.name}</p><p class="mt-1 max-w-sm truncate text-stone-500">{house.description || 'No description'}</p></td><td class="px-5 py-4 text-stone-600">/{house.slug}{#if house.domain}<br />{house.domain}{/if}</td><td class="px-5 py-4">{house._count.users}</td><td class="px-5 py-4">{house._count.auctions}</td><td class="px-5 py-4"><span class="rounded-full px-2.5 py-1 text-xs font-bold {house.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-200 text-stone-700'}">{house.isActive ? 'Active' : 'Inactive'}</span></td></tr>{:else}<tr><td colspan="5" class="px-5 py-12 text-center text-stone-500">No auction houses match your search.</td></tr>{/each}
        </tbody></table></div>
      {:else if activeTab === 'auctions'}
        <div class="overflow-x-auto"><table class="w-full min-w-[860px] text-left text-sm"><thead class="border-b border-stone-200 bg-white text-xs uppercase tracking-wide text-stone-500"><tr><th class="px-5 py-4">Auction</th><th class="px-5 py-4">House / seller</th><th class="px-5 py-4">Schedule</th><th class="px-5 py-4">Activity</th><th class="px-5 py-4">Status</th></tr></thead><tbody class="divide-y divide-stone-100">
          {#each data.auctions.filter(matches) as auction}<tr><td class="px-5 py-4"><a href={'/auctions/' + auction.id} class="font-semibold text-stone-900 hover:text-amber-800 hover:underline">{auction.title}</a><p class="mt-1 max-w-sm truncate text-stone-500">{auction.description || 'No description'}</p></td><td class="px-5 py-4"><p>{auction.auctionHouse.name}</p><p class="mt-1 text-stone-500">{auction.seller.name || auction.seller.email}</p></td><td class="px-5 py-4 text-stone-600"><p>Starts {formatDate(auction.startDate)}</p><p class="mt-1">Ends {formatDate(auction.endDate)}</p></td><td class="px-5 py-4"><p>{auction._count.lots} lots</p><p class="mt-1 text-stone-500">{auction._count.registrations} registrations</p></td><td class="px-5 py-4"><span class="rounded-full px-2.5 py-1 text-xs font-bold {statusClass(auction.status)}">{auction.status}</span></td></tr>{:else}<tr><td colspan="5" class="px-5 py-12 text-center text-stone-500">No auctions match your search.</td></tr>{/each}
        </tbody></table></div>
      {:else}
        <div class="overflow-x-auto"><table class="w-full min-w-[860px] text-left text-sm"><thead class="border-b border-stone-200 bg-white text-xs uppercase tracking-wide text-stone-500"><tr><th class="px-5 py-4">Lot</th><th class="px-5 py-4">Auction</th><th class="px-5 py-4">Pricing</th><th class="px-5 py-4">Activity</th><th class="px-5 py-4">Status</th></tr></thead><tbody class="divide-y divide-stone-100">
          {#each data.lots.filter(matches) as lot}<tr><td class="px-5 py-4"><a href={'/lots/' + lot.id} class="font-semibold text-stone-900 hover:text-amber-800 hover:underline">#{lot.lotNumber} · {lot.title}</a><p class="mt-1 text-stone-500">{lot.category || 'Uncategorized'}</p></td><td class="px-5 py-4"><p>{lot.auction.title}</p><p class="mt-1 text-stone-500">{lot.auction.auctionHouse.name}</p></td><td class="px-5 py-4"><p>Current ${lot.currentBid.toLocaleString()}</p><p class="mt-1 text-stone-500">Starts ${lot.startingBid.toLocaleString()}</p></td><td class="px-5 py-4"><p>{lot._count.bids} bids</p><p class="mt-1 text-stone-500">{lot._count.images} images · {lot._count.notes} notes</p></td><td class="px-5 py-4"><span class="rounded-full px-2.5 py-1 text-xs font-bold {statusClass(lot.status)}">{lot.status}</span></td></tr>{:else}<tr><td colspan="5" class="px-5 py-12 text-center text-stone-500">No lots match your search.</td></tr>{/each}
        </tbody></table></div>
      {/if}
    </section>
  </div>
</main>
