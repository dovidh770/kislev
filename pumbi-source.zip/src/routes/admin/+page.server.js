import prisma from '$lib/prisma.js';

export async function load() {
  try {
    const [users, auctionHouses, auctions, lots] = await Promise.all([
    prisma.user.findMany({
      orderBy: { createdAt: 'desc' },
      include: { auctionHouse: { select: { id: true, name: true } } }
    }),
    prisma.auctionHouse.findMany({
      orderBy: { createdAt: 'desc' },
      include: { _count: { select: { users: true, auctions: true } } }
    }),
    prisma.auction.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        auctionHouse: { select: { id: true, name: true } },
        seller: { select: { id: true, name: true, email: true } },
        _count: { select: { lots: true, registrations: true } }
      }
    }),
    prisma.lot.findMany({
      orderBy: [{ auction: { title: 'asc' } }, { lotNumber: 'asc' }],
      include: {
        auction: { select: { id: true, title: true, auctionHouse: { select: { name: true } } } },
        _count: { select: { bids: true, images: true, notes: true } }
      }
    })
    ]);

    return { users, auctionHouses, auctions, lots, loadError: null };
  } catch (error) {
    console.error('Unable to load admin records:', error);
    return {
      users: [],
      auctionHouses: [],
      auctions: [],
      lots: [],
      loadError: 'Pumbi could not connect to the database. Check DATABASE_URL and confirm the database is reachable.'
    };
  }
}
