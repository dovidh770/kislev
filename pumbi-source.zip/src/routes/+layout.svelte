<script>
	import '../app.css';
	let { children } = $props();
  	import Navigation from '$lib/components/Navigation.svelte';
  	import Footer from '$lib/components/Footer.svelte';
</script>

<Navigation />

{@render children()}

<Footer />
