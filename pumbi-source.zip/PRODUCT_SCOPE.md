# Pumbi Product Scope

**Purpose:** Keep the product roadmap, competitive baseline, and delivery decisions in one place. Update the status column as work is verified and shipped.

## Product position

Pumbi is the operating system and marketplace for Judaica auctions. It serves two connected audiences:

1. **Auction houses** that need a branded, reliable way to catalog, market, conduct, and settle sales.
2. **Collectors and consignors** who want a trusted place to discover, research, bid on, and sell Judaica.

The primary differentiator is the **Pumbi Open Auction**: a recurring, platform-operated Judaica sale where eligible consignors can submit lots and Pumbi curates, catalogs, markets, sells, and settles them.

## Product principles

- Judaica expertise is visible in catalog structure, provenance, condition, terminology, and discovery—not merely in the brand.
- Auction houses retain their brand, inventory control, and customer relationship.
- Trust is designed into every transaction: transparent fees, bidder approval, provenance, condition reporting, payment, shipping, and post-sale records.
- The buyer journey must work equally well on mobile and desktop, before, during, and after an auction.

## Competitive baseline: BidSpirit

The public BidSpirit material reviewed on August 17, 2026 describes live and timed auctions, absentee bidding, bidder approval and alerts, auction-house tools, catalog import, auctioneer and floor-display consoles, reporting, seller/vendor and accounting workflows, plus buy-now and post-auction sales. Treat the following as the parity target—not a claim that Pumbi has implemented it yet.

Sources: [BidSpirit product overview](https://www.bidspirit.com/ui/product?lang=en), [BidSpirit buyer FAQ](https://bidspirit.com/ui/help/bids?lang=en), [BidSpirit auction-house feature list](https://www.bidspirit-themes.com/).

## Capability map

| Area | Pumbi status today | Target / next work |
| --- | --- | --- |
| Multi-tenant auction houses | Present in data model and APIs; needs end-to-end QA | Branded public profiles, custom domains, team roles |
| Auction and lot catalog | Present; needs QA | Rich Judaica metadata, saved search, SEO catalog pages, PDF catalog |
| Timed auctions | Data model present; bidding flow needs verification | Proxy/max bids, bid increments, anti-sniping extensions, audit log |
| Live / simulcast auctions | Not verified | Real-time bidder console, stream embed, auctioneer console, clerk mode, floor display |
| Bidder onboarding | Registration and approval endpoints present; needs QA | Identity/credit-card checks, bid limits, alerts, watchlists |
| Auction-house operations | Seller screens and lot tools present; needs QA | Inventory/labels, consignment contracts, commissions, invoices, settlement |
| Media and cataloging | Image upload, background removal, voice notes, AI helpers present; needs QA | IIIF-quality zoom, condition-report templates, provenance documents, Hebrew support |
| Discovery and marketing | Basic homepage only | Search, filters, alerts, email campaigns, auction-house directory, search-indexed landing pages |
| Payments, tax, shipping | Not verified | Buyer premium/tax calculation, invoices, payment collection, shipping quotes and tracking |
| Reporting | Not verified | Auction results, bidder engagement, consignor statements, exportable reports |
| Open Auction | Not built | Monthly intake, review, curation, seller agreements, lot status, settlement |

## Delivery roadmap

### Phase 0 — Foundation and product truth

- [x] Define Judaica-first position and Open Auction concept.
- [x] Establish a competitive capability map.
- [ ] Add end-to-end tests for account, auction house, catalog, registration, bidding, and settlement flows.
- [ ] Establish environments, backups, monitoring, security review, and a production database.
- [ ] Define fees, buyer premium, tax, cancellation, condition-report, privacy, and seller terms with counsel.

### Phase 1 — Marketplace launch

- [ ] Public auction-house directory and public auction pages with indexable metadata.
- [ ] Search across lots, makers, period, origin, material, and auction house.
- [ ] Watchlists, saved searches, outbid / auction-start notifications.
- [ ] Timed-auction engine: maximum bids, increments, anti-sniping extension, complete bid audit trail.
- [ ] Bidder approval, limits, payment method capture, and fraud-review queue.
- [ ] Winning-lot invoices, buyer premiums/taxes, payment, and shipping/pickup workflow.

### Phase 2 — Auction-house operating system and BidSpirit parity

- [ ] Live simulcast bidder room with streaming, real-time lot state, and reconnect handling.
- [ ] Auctioneer console, clerk console, private support chat, and floor display.
- [ ] Absentee and telephone bidding with clear operator workflow.
- [ ] Catalog importer, spreadsheet templates, validation, bulk edit, labels, and QR codes.
- [ ] Consignor CRM, agreements, commissions, payout statements, accounting exports, and buyer invoices.
- [ ] Branded / white-label auction-house sites, custom domains, staff roles, and permissions.
- [ ] Analytics for catalog engagement, bidder conversion, sell-through, and realized price.

### Phase 3 — Judaica leadership

- [ ] Structured Judaica catalog fields: object type, ritual use, period, region, maker, inscriptions, materials, dimensions, and condition.
- [ ] Hebrew/Yiddish-aware search and transcription, including right-to-left catalog support.
- [ ] Provenance timeline, document vault, expert condition reports, and authentication review workflow.
- [ ] Specialist discovery collections: silver, manuscripts, textiles, ceremonial objects, Israeli art, and Holocaust-era material.
- [ ] Collector research tools: comparable-sale history, bibliography, saved collection, and expert inquiries.

### Phase 4 — Pumbi Open Auction

- [ ] Monthly themed sale calendar and public submission deadlines.
- [ ] Seller intake: account, item submission, images, reserve expectations, ownership and provenance attestations.
- [ ] Internal review queue: eligibility, authentication, condition, valuation, logistics, and acceptance/rejection messages.
- [ ] Consignment agreement, insured intake/shipping, lot preparation, and seller dashboard with status timeline.
- [ ] Curated catalog, pre-sale marketing, timed/live sale, payment, post-sale fulfillment, and consignor settlement.
- [ ] Publish transparent service fees, reserves, withdrawal rules, and payout schedule.

## Definition of done for a major feature

A feature is not “done” when the screen exists. It must have access control, validation, mobile UI, meaningful empty/error states, auditability where money or bids are involved, automated tests for its critical path, analytics, and user-facing help text.

## Immediate design backlog

- [x] Reposition the homepage for collectors, auction houses, and consignors.
- [x] Add a content-rich footer and page-level SEO metadata.
- [ ] Add dedicated pages for the auction-house directory, Open Auction, seller submissions, and Judaica category collections.
- [ ] Connect homepage auction cards to verified production data and graceful empty states.
